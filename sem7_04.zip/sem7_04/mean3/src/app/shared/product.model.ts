export class Product {
    _id:String;
    ProductName:String;
    ProductCompany:String;
    CategoryId:Number;
    MfgDate:Date;
    Price:Number;
    Image:String;
    Description:String;
}
